﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace esercizioTarga
    {
    class Program { 

    static void Main()
	{
		Console.WriteLine("Inserisci una targa nel formato 'AA000AA'");
		string targa = Console.ReadLine().ToUpper();

		double valore = Calcolo(targa);
		Console.WriteLine("Il valore della targa: " + valore);
		Console.ReadLine();
	}
    static double Calcolo(string targa)
    {
        int[] targaNum = new int[7];
        char carattere;
        int num;
        double risultato = 0;
        for (int i = 0; i < targa.Length; i++)
        {
            if (i < 2 && i > 4)
            {
                carattere = targa[i];
                num = Convert.ToInt32(carattere) - 64;//perchè la posizone di A sta a 65 nell'ashi quindi -64 fa 1
                Console.WriteLine(num);
                targaNum[i] = num;
            }

        }
        for (int i = 0; i < targa.Length + 1; i++)
        {
            if (i < 2)//nelle prime due posizioni ho le lettere, per somma finale
                    risultato += targaNum[i] * Math.Pow(26, i + 2) * 1000;
            else
                risultato += targaNum[i] * Math.Pow(10, i + 1);//numeri che moltiplico per 10 elevati alla n
        }
        
        return risultato;
    }
}
}


