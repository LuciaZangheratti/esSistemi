﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace esSistemiDecPuntato
{
    class Program
    {
        public static void Main(string[] args)
        {
            int[] dp = new int[4];

            for (int i = 0; i < dp.Length; i++)
            {
                Console.WriteLine($"Inserisci cifra {i + 1}");
                dp[i] = Convert.ToInt32(Console.ReadLine());
            }


        }

        //metodi:
        //bool[] Convert_DP_to_Bin(int[] dp) {return bool[]};
        //int Convert_DP_to_Int(int[] dp) {return int};
        //int Convert_Bin_to_Int(bool[] bn) {return int};
        //int[] Convert_Bin_to_DP(bool[] bn) {return int[]};

        static int[] Convert_Bin_to_DP(bool[] bn)
        {
            
        }

        //PRIMO METODO
        static bool[] Convert_DP_to_Bin(int[] dp) 
        {
            bool[] bn = new bool[32]; //array  da 32 
            int numero;

            for(int i =0; i < dp.Length; i++)
            {
                numero = dp[i]; //salvo numero che è nella posizione
                for (int j = 7; j >= 0; j--)
                {
                    bn[j] = numero % 2 == 1;
                    numero = numero / 2;
                
                }
            }
            return bn;
        }
    }
}

