﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace esSistemiDecPuntato
{
    class Program
    {
        public static void Main(string[] args)
        {
            int[] dp = new int[4];

            Console.WriteLine("Inserisci un indirizzo IP nella forma decimale (es. 192.168.56.1):");
            string indirizzo = Console.ReadLine();
            string[] spazi = indirizzo.Split('.');
            
            for(int i = 0; i < spazi.Length; i++)
            {
                if (spazi.Length != 4)
                {
                    Console.WriteLine("indirizzo IP non valido");
                }
                else
                    dp[i] = int.Parse(spazi[i]);//converto strinfa in 32 bit
            }

            bool[] bn = Convert_Dp_to_Bin(dp);

            for (int i = 0; i < bn.Length; i++)
            {
                Console.WriteLine(Convert.ToInt32(bn[i]));
            }

            Console.WriteLine(" " + Convert_Dp_to_Int(dp));
            Console.WriteLine(Convert_Bin_to_Int(bn));

            Console.WriteLine(string.Format(".", Convert_Bin_to_DP(bn)));


            Console.ReadLine();



        }

        //metodi:
        //bool[] Convert_DP_to_Bin(int[] dp) {return bool[]};
        //int Convert_DP_to_Int(int[] dp) {return int};
        //int Convert_Bin_to_Int(bool[] bn) {return int};
        //int[] Convert_Bin_to_DP(bool[] bn) {return int[]};

        static int[] Convert_Bin_to_DP(bool[] bn)
        {
            int otteto;
            int[] dp = new int[4];

            for (int i = 0; i < 4; i++)
            {
                otteto = 0;//inizializzo qua per calcolare ogni singolo otteto

                for (int j = 0; j < 8; j++)
                {
                        otteto = otteto + (int)Math.Pow(2, 7 - j);
                }

                dp[i] = otteto;
            }
            return dp;
        }

        
        static bool[] Convert_Dp_to_Bin(int[] dp) 
        {
            bool[] bn = new bool[32]; //array  da 32 
            int numero;

            for(int i =0; i < dp.Length; i++)
            {
                numero = dp[i]; //il num che è in quella poszione lo salvo 
                for (int j = 7; j >= 0; j--)
                {
                    bn[j] = numero % 2 == 1;
                    numero = numero / 2;
                
                }
            }
            return bn;
        }

        static int Convert_Bin_to_Int(bool[] bn)
        {
            int pos = bn.Length - 1;
            int num = 0;
            for (int i = 0; i < bn.Length; i++)
            { 
                    num = num + (int)Math.Pow(2, pos);
                pos--;
            }
            return num;
        }

        static int Convert_Dp_to_Int(int[] dp)
        {
            int num = 0;
            int pos = dp.Length-1;//posizione dell'ottetto 
            for (int i = 0; i < dp.Length; i++)
            {
                num = num + dp[i] * (int)Math.Pow(256, pos);
                pos--;//decremento posizione
            }

            return num;//converto un array di ottetti in un intero
        }
    }
}

